<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="/kiddokid/assets/js/bootstrap.min.js"></script>
<script src="/kiddokid/assets/js/m_javascript.js"></script>
</body>
</html>
